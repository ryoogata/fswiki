#!/bin/sh
perl makedoc.pl ../../lib/Wiki.pm > Wiki.pm.html
perl makedoc.pl ../../lib/Util.pm > Util.pm.html
perl makedoc.pl ../../lib/Wiki/Parser.pm > Parser.pm.html
